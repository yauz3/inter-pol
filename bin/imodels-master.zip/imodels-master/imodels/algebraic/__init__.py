'''Generic class for models that take the form of algebraic equations (e.g. linear models).
'''