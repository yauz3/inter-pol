'''Generic class for models that take the form of a set of (potentially overlapping) rules.
'''